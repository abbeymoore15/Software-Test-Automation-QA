
//Represents one contact
public class Contact {
    private final String contactId;
    private String firstName;
    private String lastName;
    private String phone;
    private String address;


    //Creates a contact after validating all required fields.
    public Contact(String contactId, String firstName, String lastName,
                   String phone, String address) {
        validateContactId(contactId);
        this.contactId = contactId;
        setFirstName(firstName);
        setLastName(lastName);
        setPhone(phone);
        setAddress(address);
    }

    public String getContactId() {
        return contactId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        validateRequiredLength(firstName, 10, "First name");
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        validateRequiredLength(lastName, 10, "Last name");
        this.lastName = lastName;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        if (phone == null || !phone.matches("[0-9]{10}")) {
            throw new IllegalArgumentException("Phone must contain exactly 10 digits");
        }
        this.phone = phone;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        validateRequiredLength(address, 30, "Address");
        this.address = address;
    }

    private static void validateContactId(String contactId) {
        validateRequiredLength(contactId, 10, "Contact ID");
    }

    private static void validateRequiredLength(String value, int maximumLength,
                                               String fieldName) {
        if (value == null || value.length() > maximumLength) {
            throw new IllegalArgumentException(
                    fieldName + " is required and cannot exceed " + maximumLength + " characters");
        }
    }
}
