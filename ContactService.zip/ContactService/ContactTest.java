import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.Test;

class ContactTest {

    @Test
    void constructorCreatesValidContact() {
        Contact contact = new Contact("1001", "Abbey", "Moore",
                "8565551234", "123 Main Street");

        assertEquals("1001", contact.getContactId());
        assertEquals("Abbey", contact.getFirstName());
        assertEquals("Moore", contact.getLastName());
        assertEquals("8565551234", contact.getPhone());
        assertEquals("123 Main Street", contact.getAddress());
    }

    @Test
    void constructorAcceptsMaximumFieldLengths() {
        Contact contact = new Contact("1234567890", "ABCDEFGHIJ", "KLMNOPQRST",
                "0123456789", "123456789012345678901234567890");

        assertEquals(10, contact.getContactId().length());
        assertEquals(10, contact.getFirstName().length());
        assertEquals(10, contact.getLastName().length());
        assertEquals(30, contact.getAddress().length());
    }

    @Test
    void constructorRejectsNullContactId() {
        assertThrows(IllegalArgumentException.class,
                () -> new Contact(null, "Abbey", "Moore", "8565551234", "123 Main Street"));
    }

    @Test
    void constructorRejectsLongContactId() {
        assertThrows(IllegalArgumentException.class,
                () -> new Contact("12345678901", "Abbey", "Moore", "8565551234", "123 Main Street"));
    }

    @Test
    void constructorRejectsInvalidFirstName() {
        assertThrows(IllegalArgumentException.class,
                () -> new Contact("1001", null, "Moore", "8565551234", "123 Main Street"));
        assertThrows(IllegalArgumentException.class,
                () -> new Contact("1001", "ElevenChars", "Moore", "8565551234", "123 Main Street"));
    }

    @Test
    void constructorRejectsInvalidLastName() {
        assertThrows(IllegalArgumentException.class,
                () -> new Contact("1001", "Abbey", null, "8565551234", "123 Main Street"));
        assertThrows(IllegalArgumentException.class,
                () -> new Contact("1001", "Abbey", "ElevenChars", "8565551234", "123 Main Street"));
    }

    @Test
    void constructorRejectsInvalidPhone() {
        assertThrows(IllegalArgumentException.class,
                () -> new Contact("1001", "Abbey", "Moore", null, "123 Main Street"));
        assertThrows(IllegalArgumentException.class,
                () -> new Contact("1001", "Abbey", "Moore", "856555123", "123 Main Street"));
        assertThrows(IllegalArgumentException.class,
                () -> new Contact("1001", "Abbey", "Moore", "85655512345", "123 Main Street"));
        assertThrows(IllegalArgumentException.class,
                () -> new Contact("1001", "Abbey", "Moore", "856-555-12", "123 Main Street"));
    }

    @Test
    void constructorRejectsInvalidAddress() {
        assertThrows(IllegalArgumentException.class,
                () -> new Contact("1001", "Abbey", "Moore", "8565551234", null));
        assertThrows(IllegalArgumentException.class,
                () -> new Contact("1001", "Abbey", "Moore", "8565551234",
                        "1234567890123456789012345678901"));
    }

    @Test
    void settersUpdateEditableFields() {
        Contact contact = validContact();

        contact.setFirstName("Khalil");
        contact.setLastName("Smith");
        contact.setPhone("6095559876");
        contact.setAddress("456 Oak Avenue");

        assertEquals("Khalil", contact.getFirstName());
        assertEquals("Smith", contact.getLastName());
        assertEquals("6095559876", contact.getPhone());
        assertEquals("456 Oak Avenue", contact.getAddress());
    }

    @Test
    void settersRejectInvalidValues() {
        Contact contact = validContact();

        assertThrows(IllegalArgumentException.class, () -> contact.setFirstName(null));
        assertThrows(IllegalArgumentException.class, () -> contact.setFirstName("12345678901"));
        assertThrows(IllegalArgumentException.class, () -> contact.setLastName(null));
        assertThrows(IllegalArgumentException.class, () -> contact.setLastName("12345678901"));
        assertThrows(IllegalArgumentException.class, () -> contact.setPhone(null));
        assertThrows(IllegalArgumentException.class, () -> contact.setPhone("12345abcde"));
        assertThrows(IllegalArgumentException.class, () -> contact.setAddress(null));
        assertThrows(IllegalArgumentException.class,
                () -> contact.setAddress("1234567890123456789012345678901"));
    }

    private Contact validContact() {
        return new Contact("1001", "Abbey", "Moore", "8565551234", "123 Main Street");
    }
}
