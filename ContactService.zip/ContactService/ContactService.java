import java.util.HashMap;
import java.util.Map;

//Stores contacts in memory and supports adding, deleting, and updating them.

public class ContactService {
    private final Map<String, Contact> contacts = new HashMap<>();

    
    //Adds a contact whose ID is not already stored.
    public void addContact(Contact contact) {
        if (contact == null) {
            throw new IllegalArgumentException("Contact cannot be null");
        }
        if (contacts.containsKey(contact.getContactId())) {
            throw new IllegalArgumentException("Contact ID must be unique");
        }
        contacts.put(contact.getContactId(), contact);
    }

    
    //Deletes the contact associated with the supplied ID.
    public void deleteContact(String contactId) {
        requireContact(contactId);
        contacts.remove(contactId);
    }

    
    //Updates fields for the contact associated with the ID.
    public void updateContact(String contactId, String firstName, String lastName,
                              String phone, String address) {
        Contact contact = requireContact(contactId);

        // Validate every new value before changing the stored contact.
        Contact validatedValues = new Contact(contactId, firstName, lastName, phone, address);
        contact.setFirstName(validatedValues.getFirstName());
        contact.setLastName(validatedValues.getLastName());
        contact.setPhone(validatedValues.getPhone());
        contact.setAddress(validatedValues.getAddress());
    }

    public void updateFirstName(String contactId, String firstName) {
        requireContact(contactId).setFirstName(firstName);
    }

    public void updateLastName(String contactId, String lastName) {
        requireContact(contactId).setLastName(lastName);
    }

    public void updatePhone(String contactId, String phone) {
        requireContact(contactId).setPhone(phone);
    }

    public void updateAddress(String contactId, String address) {
        requireContact(contactId).setAddress(address);
    }

    //Returns a contact by ID.
    public Contact getContact(String contactId) {
        return requireContact(contactId);
    }

    public int getContactCount() {
        return contacts.size();
    }

    private Contact requireContact(String contactId) {
        Contact contact = contacts.get(contactId);
        if (contact == null) {
            throw new IllegalArgumentException("No contact exists with ID: " + contactId);
        }
        return contact;
    }
}
