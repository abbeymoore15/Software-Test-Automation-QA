import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class ContactServiceTest {
    private ContactService service;
    private Contact contact;

    @BeforeEach
    void setUp() {
        service = new ContactService();
        contact = new Contact("1001", "Abbey", "Moore",
                "8565551234", "123 Main Street");
    }

    @Test
    void addContactStoresContact() {
        service.addContact(contact);

        assertSame(contact, service.getContact("1001"));
        assertEquals(1, service.getContactCount());
    }

    @Test
    void addContactRejectsDuplicateId() {
        service.addContact(contact);
        Contact duplicate = new Contact("1001", "Jane", "Smith",
                "6095559876", "456 Oak Avenue");

        assertThrows(IllegalArgumentException.class, () -> service.addContact(duplicate));
        assertEquals(1, service.getContactCount());
    }

    @Test
    void addContactRejectsNull() {
        assertThrows(IllegalArgumentException.class, () -> service.addContact(null));
    }

    @Test
    void deleteContactRemovesContactById() {
        service.addContact(contact);

        service.deleteContact("1001");

        assertEquals(0, service.getContactCount());
        assertThrows(IllegalArgumentException.class, () -> service.getContact("1001"));
    }

    @Test
    void deleteContactRejectsUnknownId() {
        assertThrows(IllegalArgumentException.class, () -> service.deleteContact("missing"));
    }

    @Test
    void updateContactChangesAllEditableFieldsButNotId() {
        service.addContact(contact);

        service.updateContact("1001", "Khalil", "Smith",
                "6095559876", "456 Oak Avenue");

        Contact updated = service.getContact("1001");
        assertEquals("1001", updated.getContactId());
        assertEquals("Khalil", updated.getFirstName());
        assertEquals("Smith", updated.getLastName());
        assertEquals("6095559876", updated.getPhone());
        assertEquals("456 Oak Avenue", updated.getAddress());
    }

    @Test
    void individualUpdateMethodsChangeCorrectFields() {
        service.addContact(contact);

        service.updateFirstName("1001", "Khalil");
        service.updateLastName("1001", "Smith");
        service.updatePhone("1001", "6095559876");
        service.updateAddress("1001", "456 Oak Avenue");

        assertEquals("Khalil", contact.getFirstName());
        assertEquals("Smith", contact.getLastName());
        assertEquals("6095559876", contact.getPhone());
        assertEquals("456 Oak Avenue", contact.getAddress());
    }

    @Test
    void updateContactRejectsUnknownId() {
        assertThrows(IllegalArgumentException.class,
                () -> service.updateContact("missing", "Jane", "Smith",
                        "6095559876", "456 Oak Avenue"));
    }

    @Test
    void updateContactRejectsInvalidDataWithoutPartiallyUpdatingContact() {
        service.addContact(contact);

        assertThrows(IllegalArgumentException.class,
                () -> service.updateContact("1001", "Jane", "Smith",
                        "not-a-phone", "456 Oak Avenue"));

        assertEquals("Abbey", contact.getFirstName());
        assertEquals("Moore", contact.getLastName());
        assertEquals("8565551234", contact.getPhone());
        assertEquals("123 Main Street", contact.getAddress());
    }

    @Test
    void individualUpdatesEnforceContactValidation() {
        service.addContact(contact);

        assertThrows(IllegalArgumentException.class,
                () -> service.updateFirstName("1001", "12345678901"));
        assertThrows(IllegalArgumentException.class,
                () -> service.updateLastName("1001", null));
        assertThrows(IllegalArgumentException.class,
                () -> service.updatePhone("1001", "12345"));
        assertThrows(IllegalArgumentException.class,
                () -> service.updateAddress("1001", "1234567890123456789012345678901"));
    }
}
